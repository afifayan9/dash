
<h1 align="center">Draco Dashboard</h1>
## Overview

## Installation
1. Clone the repository or download:
`git clone https://github.com/dragonlabsdev/dash`

2. go to panel directory:
`cd dash`

3. Install some importent:
`apt install zip -y && unzip dashboard.zip && cd dash && apt install nano -y && nano .env`

5. Install dependencies:
`npm install`

6. Start the Panel:
`node . # or use pm2 to keep it online`

## Contributing
Contributions to enhance the functionality or performance of the DracoPanel are encouraged. Please submit pull requests for any enhancements.

## License
(c) 2025 Hopingboyz . This software is licensed under the MIT License.




- made by hopingboyz
